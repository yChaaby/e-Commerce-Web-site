<?php
$con=mysqli_connect("localhost","root", "","php_proj") or die(mysqli_error($con));
?>
