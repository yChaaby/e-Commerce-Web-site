<?php
$conn = new PDO("mysql:host=localhost;dbname=GreenStore1", "root", "");
$con=mysqli_connect("localhost","root", "","GreenStore1") or die(mysqli_error($con));

?>